# ECLIPSE — Blood & Moon

Read docs/ESPECIFICACAO-ECLIPSE.md for the current user specification. It supersedes
older Bloodmoon limits: level cap 400 and transformation from level 10. Preserve
existing saved progress when migrating; never commit .data, .data-demo or .env.

Monorepo: apps/client (TypeScript/Vite entry + existing modular Canvas renderer),
apps/server (TypeScript database/network layers + Express entry), packages/shared
(protocol constants/types), mmo (shared gameplay and presentation modules), prisma
(schema/migrations), assets (replaceable public artwork), tests (critical rules).

The server owns movement, combat, XP, gold, items, loot, cooldowns and VIP. Never
accept client rewards or inventory snapshots. Keep authentication secrets and
inventory details out of public player broadcasts. Use salted scrypt passwords.
Real payment/email credentials remain external. Development admin seed is enabled
only with ECLIPSE_DEV=1. Do not add public privilege-granting routes.

Use npm install, npm run dev, npm run check, npm test and npm run build. Use
BLOODMOON_DATA_DIR for isolated integration fixtures. SQLite is accessed through
Prisma and migrations; legacy JSON files are backed up before database import.
Keep rule changes in modules with meaningful critical-path tests. Artwork copied
from Flare retains its license and credits. Do not replace actual gameplay with
mockups. The source specification includes features still tracked as pending;
report them accurately and do not claim production readiness without load tests.

Current artwork is original ECLIPSE production atlases under assets/eclipse.
Read docs/ARTE-INTEGRADA.md and docs/PEDIDO-ARTE-INTEGRADA.md. mmo/sprites.js
re-exports eclipse-sprites.js; Flare PNGs are historical, not the active rig.
Authoring sources are tools/art/rigs.js and props.js. Do not hand-edit manifest
coordinates without regenerating and auditing. Run scripts/audit-eclipse-art.py
after modifying PNGs; tests verify its checksums and zero clipping. Overlays can
have a wider cell than bodies while sharing projected scale and foot alignment.
Preserve Node 24 LTS restriction: Windows/Node 26 native SQLite failures were observed.

## Current delivery constraint

Stop art generation and expansion. The current user priority is one integrated vertical
slice: Vila de Eclipse + Floresta Amaldiçoada, Hunter first, and only wolf/bat/skeleton
encounters in those regions. Preserve other existing content without expanding it.
Read docs/ASSET_STATUS.md. Measure gameplay integration and run
`python3 tools/qa/vertical-slice.py` (Playwright/Chromium) for real screenshots.
Do not execute art/tiles/map generation scripts to make more unused assets.
